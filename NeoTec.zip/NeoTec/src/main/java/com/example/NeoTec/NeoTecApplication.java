package com.example.NeoTec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeoTecApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeoTecApplication.class, args);
	}

}
